// inventory.js

import NicknameSystem from "./nicknameSystem.js";

// Получение текущего никнейма
let currentNickname = localStorage.getItem("currentNickname");

if (!currentNickname || !NicknameSystem.doesNicknameExist(currentNickname)) {
  console.error("Не найден текущий никнейм. Инвентарь не может быть инициализирован.");
}

// Переменная для хранения информации о переносимом предмете
let draggedItemIndex = null;

// Функция загрузки инвентаря для текущего никнейма
function loadInventoryForNickname(nickname) {
  const playerData = NicknameSystem.getPlayerData(nickname);
  return playerData?.inventory || [];
}

// Инициализация инвентаря для текущего никнейма
export let inventory = loadInventoryForNickname(currentNickname);

// Обновление текущего никнейма и перезагрузка инвентаря
export function updateCurrentNickname(newNickname) {
  if (NicknameSystem.doesNicknameExist(newNickname)) {
    currentNickname = newNickname;
    localStorage.setItem("currentNickname", newNickname);
    inventory = loadInventoryForNickname(newNickname);
    console.log(`Инвентарь обновлён для никнейма: ${newNickname}`);
  } else {
    console.error("Никнейм не существует. Обновление не выполнено.");
  }
}

// Сохранение инвентаря игрока в систему никнеймов
export function saveInventoryToNicknameSystem() {
  if (currentNickname) {
    const playerData = NicknameSystem.getPlayerData(currentNickname);
    if (playerData) {
      playerData.inventory = inventory;
      NicknameSystem.updatePlayerData(currentNickname, playerData);
    } else {
      console.error("Ошибка: Данные игрока не найдены.");
    }
  } else {
    console.error("Невозможно сохранить инвентарь: текущий никнейм отсутствует.");
  }
}

// Добавление предметов в инвентарь
export function addToInventory(items) {
  items.forEach((item) => {
    const existingSlot = inventory.find((slot) => slot.name === item.name);
    if (existingSlot) {
      existingSlot.count += item.count;
    } else {
      const emptySlot = inventory.find((slot) => !slot.name);
      if (emptySlot) {
        emptySlot.name = item.name;
        emptySlot.count = item.count;
      } else {
        console.warn("Инвентарь заполнен!");
      }
    }
  });
  saveInventoryToNicknameSystem();
}

// Обработчики событий drag-and-drop
export function setupDragAndDrop(containerElement) {
  containerElement.addEventListener("dragstart", (event) => {
    const slotElement = event.target.closest(".inventory-slot");
    if (!slotElement) return;

    draggedItemIndex = Number(slotElement.getAttribute("data-slot-id")) - 1;
    event.dataTransfer.setData("text/plain", draggedItemIndex);
    event.dataTransfer.effectAllowed = "move";
  });

  containerElement.addEventListener("dragover", (event) => {
    event.preventDefault(); // Разрешить сброс
    event.dataTransfer.dropEffect = "move";
  });

  containerElement.addEventListener("drop", (event) => {
    event.preventDefault();

    const targetSlotElement = event.target.closest(".inventory-slot");
    if (!targetSlotElement || draggedItemIndex === null) return;

    const targetSlotIndex = Number(targetSlotElement.getAttribute("data-slot-id")) - 1;

    if (draggedItemIndex !== targetSlotIndex) {
      // Обмен местами предметов
      const temp = inventory[draggedItemIndex];
      inventory[draggedItemIndex] = inventory[targetSlotIndex];
      inventory[targetSlotIndex] = temp;

      // Сохранить изменения и обновить интерфейс
      saveInventoryToNicknameSystem();
      updateInventoryUI(containerElement);
    }

    draggedItemIndex = null;
  });
}

// Обновление интерфейса инвентаря
export function updateInventoryUI(containerElement) {
  containerElement.innerHTML = ""; // Очищаем все слоты
  inventory.forEach((slot, index) => {
    const slotElement = document.createElement("div");
    slotElement.classList.add("inventory-slot");
    slotElement.setAttribute("data-slot-id", index + 1);
    slotElement.setAttribute("draggable", "true"); // Разрешить перетаскивание

    if (slot.name) {
      const img = document.createElement("img");
      img.src = `./assets/${slot.name.replace(/\s/g, "_")}.png`;
      img.alt = slot.name;
      img.style.width = "80%";
      img.style.height = "80%";
      slotElement.appendChild(img);

      const count = document.createElement("div");
      count.textContent = slot.count;
      count.style.position = "absolute";
      count.style.bottom = "5px";
      count.style.right = "5px";
      count.style.color = "white";
      count.style.backgroundColor = "rgba(0, 0, 0, 0.7)";
      count.style.padding = "2px 5px";
      count.style.borderRadius = "3px";
      slotElement.appendChild(count);
    }

    containerElement.appendChild(slotElement);
  });

  // Подключаем drag-and-drop функционал
  setupDragAndDrop(containerElement);
}

// Инициализация пустых слотов в инвентаре
export function initializeInventorySlots(slotCount = 98) {
  while (inventory.length < slotCount) {
    inventory.push({ id: inventory.length + 1, name: null, count: 0 });
  }
  saveInventoryToNicknameSystem();
}

// Подсчёт монет в никнейм системе
function addCoinsToNickname(nickname, coins) {
  const playerData = NicknameSystem.getPlayerData(nickname);
  if (playerData) {
    playerData.coins = (playerData.coins || 0) + coins;
    NicknameSystem.updatePlayerData(nickname, playerData);
  }
}

// Продажа всех предметов
function sellAllItems() {
  const totalItems = inventory.reduce((sum, slot) => sum + (slot.count || 0), 0);
  const totalCoins = totalItems * 5; // 5 монет за предмет
  if (totalItems > 0) {
    inventory.forEach(slot => {
      slot.name = null;
      slot.count = 0;
    });
    addCoinsToNickname(currentNickname, totalCoins);
    saveInventoryToNicknameSystem();
    alert(`Вы продали все предметы за ${totalCoins} монет!`);
    updateInventoryUI(document.querySelector(".inventory-grid"));
  } else {
    alert("Ваш инвентарь пуст!");
  }
}

// Выделение слотов для продажи
let selectedSlots = new Set();
function toggleSlotSelection(slotIndex) {
  const slotElement = document.querySelector(`[data-slot-id="${slotIndex}"]`);
  if (!slotElement) return;

  if (selectedSlots.has(slotIndex)) {
    selectedSlots.delete(slotIndex);
    slotElement.classList.remove("selected");
  } else {
    selectedSlots.add(slotIndex);
    slotElement.classList.add("selected");
  }
}

// Продажа выбранных предметов
function sellSelectedItems() {
  const selectedItems = Array.from(selectedSlots).map(index => inventory[index - 1]);
  const totalCoins = selectedItems.reduce((sum, slot) => sum + (slot.count || 0) * 5, 0);

  if (selectedItems.length === 0) {
    alert("Вы не выбрали ни одного предмета!");
    return;
  }

  selectedItems.forEach(slot => {
    slot.name = null;
    slot.count = 0;
  });

  addCoinsToNickname(currentNickname, totalCoins);
  saveInventoryToNicknameSystem();
  alert(`Вы продали выбранные предметы за ${totalCoins} монет!`);
  selectedSlots.clear();
  updateInventoryUI(document.querySelector(".inventory-grid"));
}

// Исправление событий для кнопок
document.addEventListener("DOMContentLoaded", () => {
  const sellAllButton = document.getElementById("sell-all-button");
  const sellSelectedButton = document.getElementById("sell-selected-button");
  const inventoryGrid = document.querySelector(".inventory-grid");

  if (!sellAllButton || !sellSelectedButton || !inventoryGrid) {
    console.error("Не удалось найти элементы для кнопок или инвентаря.");
    return;
  }

  sellAllButton.addEventListener("click", () => {
    const modal = document.getElementById("confirmation-modal");
    if (!modal) {
      console.error("Не найден модальное окно подтверждения.");
      return;
    }

    document.getElementById("confirmation-text").textContent =
      "Вы уверены, что хотите продать все предметы?";
    modal.classList.remove("hidden");

    document.getElementById("confirm-sell-button").onclick = () => {
      sellAllItems();
      modal.classList.add("hidden");
    };

    document.getElementById("cancel-sell-button").onclick = () => {
      modal.classList.add("hidden");
    };
  });

  sellSelectedButton.addEventListener("click", () => {
    const modal = document.getElementById("confirmation-modal");
    if (!modal) {
      console.error("Не найден модальное окно подтверждения.");
      return;
    }

    document.getElementById("confirmation-text").textContent =
      "Вы уверены, что хотите продать выбранные предметы?";
    modal.classList.remove("hidden");

    document.getElementById("confirm-sell-button").onclick = () => {
      sellSelectedItems();
      modal.classList.add("hidden");
    };

    document.getElementById("cancel-sell-button").onclick = () => {
      modal.classList.add("hidden");
    };
  });

  // Добавление выделения при клике на слот
  inventoryGrid.addEventListener("click", (event) => {
    const slot = event.target.closest(".inventory-slot");
    if (slot) toggleSlotSelection(Number(slot.getAttribute("data-slot-id")));
  });
});

